const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const path = require('path');
const cors = require('cors');

const app = express();
const port = 4000;

app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname)));
app.use(session({
    secret: 'secure-key',
    resave: false,
    saveUninitialized: true,
}));

// Connect to SQLite database
const db = new sqlite3.Database(path.join(__dirname, 'database.sqlite'), (err) => {
    if (err) {
        console.error('Error opening database', err.message);
    } else {
        console.log('Connected to SQLite database');
    }
});

// Create table with soft delete column
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS instructors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        contact TEXT NOT NULL,
        address TEXT NOT NULL,
        hashed_password TEXT NOT NULL,
        is_deleted INTEGER DEFAULT 0  -- Soft delete column (0 = active, 1 = deleted)
    )`);
});

// Validation function
const checkPassword = (password) => {
    if (password.length < 6) return "Password must be at least 8 characters long.";
    
    let hasLetter = false, hasDigit = false;

    for (let i = 0; i < password.length; i++) {
        let ch = password[i];
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) hasLetter = true;
        if (ch >= '0' && ch <= '9') hasDigit = true;
    }

    if (!hasLetter) return "Password must contain at least one letter.";
    if (!hasDigit) return "Password must contain at least one number.";
    
    return "Valid";
};



const validateInput = (username, password, email, contact, address) => {
    const usernameRegex = /^[a-zA-Z0-9]{3,20}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const contactRegex = /^\d{10}$/;
    
    if (!usernameRegex.test(username)) return "Invalid username. Must be 3-20 alphanumeric characters.";
    if (!emailRegex.test(email)) return "Invalid email format.";
    if(checkPassword(password) !== "Valid") return "password have one letter and one number"
    if (!contactRegex.test(contact)) return "Invalid contact number. Must be 10 digits.";
    if (!address.trim()) return "Address cannot be empty.";
    
    return null;
};

// Home route
app.get('/', (req, res) => {
    if (req.session.instructor) {
        res.redirect('/home');
    } else {
        res.sendFile(path.join(__dirname, 'login.html'));
    }
});

app.get('/login.html', (req, res) => {
    if (req.session.instructor) {
        res.redirect('/home');
    } else {
        res.sendFile(path.join(__dirname, 'login.html'));
    }
});

app.get('/home', (req, res) => {
    if (req.session.instructor) {
        res.sendFile(path.join(__dirname, 'home.html'));
    } else {
        res.status(403).send('Unauthorized.');
    }
});

// Restore route
app.get('/restore', (req, res) => {
    if (req.session.instructor) {
        res.redirect('/home');
    } else {
        res.sendFile(path.join(__dirname, 'restore.html'));
    }
});

// Signup route (allows duplicate usernames but enforces unique emails)
app.post('/signup', (req, res) => {
   
    const { username, password, email, contact, address } = req.body;
    const error = validateInput(username, password, email, contact, address);
    if (error) return res.status(400).send(error);

    db.get('SELECT * FROM instructors WHERE email = ?', [email], (err, user) => {
        if (err) return res.status(500).send('Database error.');
        if (user) {
            if (user.is_deleted === 0) {
                return res.status(400).send('Email already exists.');
            } else {
                if (user.is_deleted === 1){
                    return res.status(400).send(' Account exists but is deleted. Please <a href="/restore.html">restore your account</a>.');

                }
            }
        }

        bcrypt.hash(password, 10, (err, hashedPassword) => {
            if (err) return res.status(500).send('Error hashing password.');
            db.run(
                'INSERT INTO instructors (name, email, contact, address, hashed_password, is_deleted) VALUES (?, ?, ?, ?, ?, 0)',
                [username, email, contact, address, hashedPassword],
                (err) => {
                    if (err) return res.status(500).send('Error signing up.');
                    res.redirect('/');
                }
            );
        });
    });
});

// Login route (uses email instead of username)
app.post('/login', (req, res) => {
    

    const { email, password } = req.body;
    db.get('SELECT * FROM instructors WHERE email = ? AND is_deleted = 0', [email], (err, user) => {
        if (err) return res.status(500).send('Database error.');
        if (!user) return res.status(400).send('Invalid email or password.');

        bcrypt.compare(password, user.hashed_password, (err, match) => {
            if (err) return res.status(500).send('Error comparing passwords.');
            if (match) {
                req.session.instructor = user.id;
                res.redirect('/');
            } else {
                res.status(400).send('Invalid email or password.');
            }
        });
    });
});

// Soft delete user
app.delete('/delete', (req, res) => {
    if (!req.session.instructor) return res.status(403).send('Unauthorized.');

    db.run('UPDATE instructors SET is_deleted = 1 WHERE id = ?', [req.session.instructor], function (err) {
        if (err) return res.status(500).send('Error deleting user.');
        req.session.destroy();
        res.send('User account soft deleted.');
    });
});

// Restore soft-deleted user
app.post('/restore', (req, res) => {
    const { email } = req.body;
    db.get('SELECT * FROM instructors WHERE email = ? AND is_deleted = 1', [email], (err, user) => {
        if (err) return res.status(500).send('Database error.');
        if (!user) return res.status(400).send('No deleted user found with this email.');

        db.run('UPDATE instructors SET is_deleted = 0 WHERE email = ?', [email], function (err) {
            if (err) return res.status(500).send('Error restoring account.');
            res.send('User account restored.');
        });
    });
});

// Logout route
app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) console.error('Error destroying session:', err);
        res.redirect('/');
    });
});

// Signup page route
app.get('/signup', (req, res) => {
    if(req.session.instructor) return res.send("Already logined ");
    else
    res.sendFile(path.join(__dirname, 'signup.html'));
});

// Get all users (admin use)
app.get('/getUsers', (req, res) => {
    db.all('SELECT * FROM instructors', [], (err, rows) => {
        if (err) return res.status(500).send('Database error.');
        res.json(rows);
    });
});

// Admin deletes a user (soft delete)
app.delete('/deleteUser', (req, res) => {
    const { id } = req.body;
    db.run('UPDATE instructors SET is_deleted = 1 WHERE id = ?', [id], function (err) {
        if (err) return res.status(500).send('Error deleting user.');
        res.send('User deleted.');
    });
});

// Admin dashboard
app.get('/admin', (req, res) => {
    res.sendFile(__dirname + '/admin.html');
});

app.put("/updateUser", (req, res) => {
    const { id, field, value } = req.body;

    if (!id || !field || value === undefined) {
        return res.status(400).send("Invalid request parameters.");
    }

    const allowedFields = ["name", "email", "contact", "address"];
    if (!allowedFields.includes(field)) {
        return res.status(400).send("Invalid field.");
    }

    const sql = `UPDATE instructors SET ${field} = ? WHERE id = ?`;
    db.run(sql, [value, id], function (err) {
        if (err) {
            return res.status(500).send("Error updating user.");
        }
        res.send("User updated successfully.");
    });
});

app.get("/load_user_info", (req, res) => {
    if (!req.session.instructor) {
        return res.status(403).send("Unauthorized.");
    }

    const userId = req.session.instructor;
    db.get("SELECT id, name, email, contact, address FROM instructors WHERE id = ?", [userId], (err, row) => {
        if (err) return res.status(500).send("Error fetching user.");
        if (!row) return res.status(404).send("User not found.");
        res.json(row);
    });
});


app.get('/update', (req, res) => {
    if (req.session.instructor) return res.status(200).sendFile(__dirname+'/update_info.html');
    else res.status(403).send('unathurized');
});

// Start server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
